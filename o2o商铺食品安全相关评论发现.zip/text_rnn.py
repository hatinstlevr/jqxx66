#!/usr/bin/env python
# _*_coding:utf-8_*_
"""
@Time :    2022年11月1日21:58:50
@Author:  hechunxiong
@File:   text_rnn.py
"""
from keras.layers import *
import jieba
import multiprocessing
import pandas as pd
from gensim.models import Word2Vec
import numpy as np
import keras.backend as K
from keras.callbacks import Callback, ModelCheckpoint
from keras.models import Model
from keras.utils.np_utils import to_categorical
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import classification_report, accuracy_score, f1_score
import ipykernel


def token(text):
    """
    实现分词
    :param text:文本
    :return:
    """
    #进行精确分词
    return " ".join(jieba.cut(text))# 把分词结果用空格组成字符串



def train_w2v(text_list=None, output_vector='data/w2v.txt'):
    """
    训练word2vec
    :param text_list:文本列表
    :param output_vector:词向量输出路径
    :return:
    """
    print("正在训练词向量。。。")
    corpus = [text.split() for text in text_list]
    #读取分好的词，进行训练
    model = Word2Vec(corpus, size=100, window=5, min_count=1, workers=multiprocessing.cpu_count())
    # 模型保存，保存词向量，保存为vector文件
    model.wv.save_word2vec_format(output_vector, binary=False)

#读取数据
# sample.csv
# testtest_new.csv
# train.csv
train = pd.read_csv('data/train.csv', sep='\t')
test = pd.read_csv('data/test_new.csv')
sample = pd.read_csv('data/sample.csv')

# 数据处理 复制label为1文本
# index = train.label == 1
# print(index)
# train[index]
# train.['comment'] = train[index]['comment'].apply(lambda x: x +'。'+ x)

    # 创建新表以及标签
train['id'] = [i for i in range(len(train))]
test['label'] = [-1 for i in range(len(test))]
    #合并
df = pd.concat([train, test], sort=False)
    #将数据写入表格
df['token_text'] = df['comment'].apply(lambda x: token(x))
    #将dataframe类型转化为list类型
texts = df['token_text'].values.tolist()
# train_w2v(texts)

# 构建词汇表,进行词的编号
tokenizer = Tokenizer()   #文本拆分为标记
tokenizer.fit_on_texts(texts) #通过文档列表更新tokenizer的词典
word_index = tokenizer.word_index #查看texts中所有文本，并将文本与对应数字进行匹配
print("词语数量个数：{}".format(len(word_index))) #打印词语数量

# 数据
EMBEDDING_DIM = 100  #词向量维度
MAX_SEQUENCE_LENGTH = 100 #最大序列长度

sequences = tokenizer.texts_to_sequences(texts)
data = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH) # #将长度不足 100 的文本用 0 填充（在前端填充）

# 类别编码
x_train = data[:len(train)] # 训练样本特征
x_test = data[len(train):] # 测试样本特征
y_train = to_categorical(train['label'].values) # 训练样本标签列
y_train = y_train.astype(np.int32)
print(y_train)


# 创建embedding_layer
def create_embedding(word_index, w2v_file):
    """

    :param word_index: 词语索引字典
    :param w2v_file: 词向量文件
    :param embedding_matrix:存储所有 word2vec 中所有向量的数组，用于初始化模型 Embedding 层
    :return:
    """
    #从w2v_file文件中解析出每个词和它所对应的词向量，并用字典的方式存储
    embedding_index = {}
    f = open(w2v_file, 'r', encoding='utf-8')
    next(f)  # 下一行
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embedding_index[word] = coefs
    f.close()
    #打印出w2v_file中词向量数
    print("Found %s word vectors in w2v_file" % len(embedding_index))

    # word_index 包含语料库中的单词，embedding_index是预先训练的嵌入
    embedding_matrix = np.random.random(size=(len(word_index) + 1, EMBEDDING_DIM)) #根据得到的字典构建词向量矩阵
    for word, i in word_index.items():
        embedding_vector = embedding_index.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector
     #现在我们将这个词向量举证加载到Embedding 层中，注意，我们设置trainable=True使得这个编码层可再训练
    embedding_layer = Embedding(len(word_index) + 1,
                                EMBEDDING_DIM, weights=[embedding_matrix],
                                input_length=MAX_SEQUENCE_LENGTH, trainable=True)
    return embedding_layer

#将layers分组为具有训练和推理特征的对象
def create_text_rnn():
    input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
    # embedding
    embedding_layer = create_embedding(word_index, 'data/w2v.txt')
    embedding_input = embedding_layer(input)
    #lstm
    l_lstm = LSTM(128)(embedding_input)#将上一个输出返回，体现rnn信息“循环”利用。
    output = Dense(2, activation='softmax')(l_lstm) #使用softmax激活函数进行多分类，指定维数为2
    model = Model(inputs=input, outputs=output) #最后从输入和输出创建模型
    return model


train_pred = np.zeros((len(train), 2))
test_pred = np.zeros((len(test), 2))



"""
shuffle:是否在每次分割之前打乱顺序
n_splits:折叠次数
random_state:随机种子,在shuffle==True时使用，默认使用np.random
"""
skf = StratifiedKFold(n_splits=5, random_state=52, shuffle=True)
#对训练集进行交叉验证
for i, (train_index, valid_index) in enumerate(skf.split(x_train, train['label'])):
    print("n@:{}fold".format(i + 1))
    X_train = x_train[train_index]  # 按照行索引 获取数据
    X_valid = x_train[valid_index]  # 验证集
    y_tr = y_train[train_index]
    y_val = y_train[valid_index]

    model = create_text_rnn()
    #配置函数
    model.compile(loss='categorical_crossentropy', #loss损失函数
                  optimizer='rmsprop', #优化器
                  metrics=['acc']) #监控指标
    model.summary() #输出模型各层的参数状况
#保存和加载模型
    checkpoint = ModelCheckpoint(filepath='rnn_text_{}.h5'.format(i + 1), #保存模型文件的路径
                                 monitor='val_loss', #验证集精度
                                 verbose=1,#显示保存记录
                                 save_best_only=True) #保留最好的
    history = model.fit(X_train, y_tr,  #模型保存参数
                        validation_data=(X_valid, y_val),#这个参数会覆盖 validation_split，它的输入为元组 (x_valid，y_val)，这作为验证数据。
                        epochs=10,#迭代次数
                        batch_size=16,#整数 ，每次梯度更新的样本数即批量大小
                        callbacks=[checkpoint]) #这个list中的回调函数将会在训练过程中的适当时机被调用

    # model.load_weights('cnn_text.h5')
    train_pred[valid_index, :] = model.predict(X_valid)#输出预测结果
    test_pred += model.predict(x_test)

labels = np.argmax(test_pred, axis=1)#取出test_pred中元素最大值所对应的索引,在列方向比较
sample['label'] = labels
sample.to_csv('result/rnn.csv', index=None)

# 训练数据预测结果
# 概率
oof_df = pd.DataFrame(train_pred)
train = pd.concat([train, oof_df], axis=1) #行对齐，将不同列名称的两张表合并
# 标签
labels = np.argmax(train_pred, axis=1)
train['pred'] = labels
# 分类报告
train.to_excel('result/rnn_train.xlsx', index=None)
print(classification_report(train['label'].values, train['pred'].values))
print(f1_score(train['label'].values, train['pred'].values))
